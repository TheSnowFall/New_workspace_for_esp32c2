

#ifndef MAIN_CJSON_PARSER_H_
#define MAIN_CJSON_PARSER_H_





#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"





uint8_t BLE_packet_parser(uint8_t* buffer);





#endif /* MAIN_CJSON_PARSER_H_ */
